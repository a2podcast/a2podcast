---
name: audio-transcription
description: "Trascrivi file audio in locale su qualsiasi piattaforma: Apple Silicon (parakeet-mlx), Intel Mac (whisper.cpp), Linux/Windows con GPU (faster-whisper), Linux/Windows CPU (whisper.cpp). Usa quando l'utente vuole trascrivere audio, generare SRT/VTT/TXT, installare un tool di trascrizione, o sa che usa parakeet, whisper o faster-whisper."
metadata:
  version: "2.0.0"
  author: "filippostrozzi"
---

# Audio Transcription

Trascrizione audio locale su qualsiasi piattaforma — il tool giusto viene scelto in base all'hardware.

## Quick Reference

**Step 1 — Rileva la piattaforma:**
```bash
python3 -c "import platform; print(platform.system(), platform.machine())"
```

**Step 2 — Vai alla sezione corrispondente:**

| Output | Piattaforma | Tool consigliato |
|---|---|---|
| `Darwin arm64` | Apple Silicon (M1+) | [parakeet-mlx](#apple-silicon-darwin-arm64) |
| `Darwin x86_64` | Intel Mac | [whisper.cpp](#intel-mac-darwin-x86_64) |
| `Linux x86_64` + GPU NVIDIA | Linux Intel con GPU | [faster-whisper CUDA](#linux-con-nvidia-gpu) |
| `Linux x86_64` + no GPU | Linux Intel CPU | [faster-whisper CPU](#linux-cpu--linux-arm) |
| `Linux aarch64` | Linux ARM | [faster-whisper CPU](#linux-cpu--linux-arm) |
| `Windows AMD64` + GPU NVIDIA | Windows con GPU | [faster-whisper CUDA](#windows) |
| `Windows AMD64` + no GPU | Windows CPU | [whisper.cpp binari](#windows) |

---

## Apple Silicon (Darwin arm64)

**Tool:** `parakeet-mlx` — Parakeet TDT v3, 25 lingue EU, ~4.3% WER sull'italiano.

### Installazione

```bash
# Verifica se già installato
which parakeet-mlx

# Installa (prima esecuzione scarica il modello, ~1.2 GB)
uv tool install parakeet-mlx
```

### Trascrizione

```bash
# SRT (formato default — nessun flag necessario)
parakeet-mlx "episodio.mp3" \
  --model mlx-community/parakeet-tdt-0.6b-v3 \
  --output-dir ./

# Tutti i formati insieme (SRT + VTT + TXT + JSON)
parakeet-mlx "episodio.mp3" --output-format all --output-dir ./
```

### Modelli disponibili

| Modello | Lingue | RAM | Quando usarlo |
|---|---|---|---|
| `mlx-community/parakeet-tdt-0.6b-v3` | 25 EU | ~2 GB | **Default — italiano e lingue EU** |
| `animaslabs/parakeet-tdt-0.6b-v3-mlx-8bit` | 25 EU | ~1 GB | RAM limitata |
| `animaslabs/parakeet-tdt-0.6b-v3-mlx-4bit` | 25 EU | ~0.5 GB | Mac con poca RAM |
| `mlx-community/parakeet-tdt-0.6b-v2` | Solo EN | ~1.2 GB | Audio in inglese puro |

### Opzioni avanzate

```bash
# Qualità migliore, più lento
parakeet-mlx "episodio.mp3" --decoding beam --output-dir ./

# Riduce uso memoria per audio molto lunghi (>30 min)
parakeet-mlx "episodio.mp3" --local-attention --output-dir ./

# Controlla segmentazione SRT (righe troppo lunghe o tagli errati)
parakeet-mlx "episodio.mp3" --silence-gap 1.0 --max-words 12 --output-dir ./

# Debug con confidence score
parakeet-mlx "episodio.mp3" --verbose --output-dir ./
```

---

## Intel Mac (Darwin x86_64)

**Tool:** `whisper.cpp` — ottimizzato per CPU, il più veloce su Mac Intel (Core ML non disponibile su x86).

> **Nota:** whisper.cpp accetta solo WAV 16kHz mono. Il passo ffmpeg è obbligatorio per file MP3.

### Installazione

```bash
brew install whisper-cpp ffmpeg
```

Scarica il modello (prima volta):
```bash
# Modello medium — miglior bilanciamento qualità/velocità su CPU Intel
curl -L -o ~/Downloads/ggml-medium.bin \
  https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-medium.bin
```

### Trascrizione

```bash
# Step 1: converti MP3 → WAV (obbligatorio)
ffmpeg -i "episodio.mp3" -ar 16000 -ac 1 episodio.wav

# Step 2: trascrivi in SRT
whisper-cpp --language it \
  --model ~/Downloads/ggml-medium.bin \
  --output-srt \
  episodio.wav
```

> **Output:** whisper.cpp genera `episodio.wav.srt` — rinomina se necessario:
> ```bash
> mv episodio.wav.srt episodio.srt
> ```

### Modelli disponibili

| Modello | Accuratezza IT | Dimensione | Tempo (CPU Intel) |
|---|---|---|---|
| `ggml-small.bin` | buona | 244 MB | ~15 min/ora audio |
| `ggml-medium.bin` | ottima | 769 MB | ~45 min/ora audio |
| `ggml-large-v3.bin` | eccellente | 1.5 GB | ~90 min/ora audio |

---

## Linux con NVIDIA GPU

**Tool:** `faster-whisper` — usa CTranslate2 con CUDA, fino a 4× più veloce di Whisper originale.

**Requisiti:** CUDA 12 + cuDNN 9, driver NVIDIA aggiornati.

### Installazione

```bash
pip install faster-whisper faster-whisper-cli
pip install nvidia-cublas-cu12 "nvidia-cudnn-cu12==9.*"
```

Verifica GPU:
```bash
nvidia-smi  # deve rispondere con info sulla GPU
```

### Trascrizione

```bash
# Italiano, SRT, GPU
faster-whisper-cli "episodio.mp3" \
  --language it \
  --model large-v3 \
  --device cuda \
  --output_format srt
```

### Alternativa: Parakeet via onnx-asr

Se vuoi usare Parakeet v3 (stesso modello di Apple Silicon) invece di Whisper:

```bash
pip install onnx-asr

# Trascrizione (output testo, non SRT nativo)
onnx-asr transcribe --model nemo-parakeet-tdt-0.6b-v3 episodio.wav
```

> **Limitazione:** `onnx-asr` non genera SRT — usa il testo grezzo. Per SRT usa `faster-whisper-cli`.

---

## Linux CPU / Linux ARM

**Tool:** `faster-whisper` in modalità CPU con quantizzazione int8.

### Installazione

```bash
pip install faster-whisper faster-whisper-cli
```

### Trascrizione

```bash
# CPU con int8 (più veloce su CPU)
faster-whisper-cli "episodio.mp3" \
  --language it \
  --model medium \
  --device cpu \
  --compute_type int8 \
  --output_format srt
```

> Su CPU un'ora di audio con modello `medium` richiede circa 20-40 minuti. Usa `small` per ridurre i tempi.

---

## Windows

**Verifica GPU NVIDIA:**
```powershell
nvidia-smi
```

### Con GPU NVIDIA → faster-whisper

```bash
pip install faster-whisper faster-whisper-cli
pip install nvidia-cublas-cu12 "nvidia-cudnn-cu12==9.*"

faster-whisper-cli "episodio.mp3" --language it --model large-v3 --device cuda --output_format srt
```

### Senza GPU → whisper.cpp (binari precompilati)

1. Scarica l'archivio da: `github.com/ggml-org/whisper.cpp/releases` → `whisper-bin-x64.zip`
2. Estrai in `C:\whisper.cpp\`
3. Installa ffmpeg: `winget install ffmpeg` oppure `choco install ffmpeg`
4. Scarica un modello ggml dalla stessa pagina release

```powershell
# Step 1: converti MP3 → WAV
ffmpeg -i episodio.mp3 -ar 16000 -ac 1 episodio.wav

# Step 2: trascrivi
C:\whisper.cpp\main.exe -l it -m C:\whisper.cpp\ggml-medium.bin -f episodio.wav --output-srt
```

> **Output:** genera `episodio.wav.srt` — rinomina in `episodio.srt` se necessario.

> **Nota:** non usare `uname` su Windows — usa sempre il comando Python del Quick Reference per rilevare la piattaforma.

---

## Troubleshooting

**`whisper.cpp` genera `episodio.wav.srt` invece di `episodio.srt`**
```bash
mv episodio.wav.srt episodio.srt          # macOS/Linux
ren episodio.wav.srt episodio.srt         # Windows cmd
```

**ffmpeg non trovato (Intel Mac)**
```bash
brew install ffmpeg
```

**CUDA non rilevato da faster-whisper**
```bash
nvidia-smi          # verifica che i driver siano attivi
pip install nvidia-cublas-cu12 "nvidia-cudnn-cu12==9.*"
```

**Download HuggingFace lento / rate limited**
```bash
export HF_TOKEN="hf_tuotoken"   # macOS/Linux
$env:HF_TOKEN="hf_tuotoken"     # Windows PowerShell
```
Genera il token su: huggingface.co → Settings → Access Tokens

**Errore MLX all'avvio di parakeet-mlx**
→ Il Mac non è Apple Silicon. Passa alla sezione Intel Mac.

**`parakeet-mlx` non trovato dopo installazione uv**
```bash
source ~/.zshrc
# oppure usa path completo:
~/.local/bin/parakeet-mlx "episodio.mp3" --output-dir ./
```
